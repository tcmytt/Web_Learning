<p style="text-align: center;font-weight: bold;font-size: 30px;margin-top: 30px;">Thêm danh mục sản phẩm</p>
<table class="table table-bordered" style="width: 60%;margin: 0 auto;">
    <form method="POST" action="modules/quanlydanhmuc/xuly.php">
        <tr>
            <td>Tên danh mục</td>
            <td><input type="text" size="35" name="tendanhmuc"></td>
        </tr>
        <tr>
            <td>Thứ tự</td>
            <td><input type="text" size="35" name="thutu"></td>
        </tr>
        <tr>
            <td colspan="2"><input type="submit" style="margin-left: 35%;" name="themdanhmuc"
                    value="Thêm danh mục sản phẩm"></td>
        </tr>
    </form>
</table>