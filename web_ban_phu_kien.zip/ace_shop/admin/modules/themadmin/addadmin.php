<form action="modules/themadmin/xuly.php" autocomplete="off" class="box-dangky" method="POST">
    <h1>Đăng ký (Admin)</h1>
    <input type="text" name="name" placeholder="Họ và tên">
    <input type="text" name="username" placeholder="Tên đăng nhập">
    <input type="password" name="password" placeholder="Mật khẩu">
    <input type="submit" name="dangky" value="Đăng ký">
</form>