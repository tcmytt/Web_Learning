<h2 style="text-align:center">Thống kê đơn hàng theo: <span id="text-date"></span></h2>
<div class="contaiter-fuild d-flex justify-content-center">
    <p>
        <select class="form-select select-date">
            <option value="homnay">Hôm nay</option>
            <option value="7ngay">7 ngày qua</option>
            <option value="28ngay">28 ngày qua</option>
            <option value="90ngay">90 ngày qua</option>
            <option value="365ngay">365 ngày qua</option>
        </select>
    </p>
</div>
<div id="chart" style="height: 250px;width:99%"></div>